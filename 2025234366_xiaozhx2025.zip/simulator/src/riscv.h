#ifndef SRC_RISCV_H_
#define SRC_RISCV_H_

#include <array>
#include <cassert>
#include <cstdint>
#include <limits>
#include <string>

#include "memory_manager.h"

// create a bitmask for lower `bits`
constexpr uint64_t BITMASK(int bits) {
  // to avoid UDB
  if (bits >= 64) {
    return std::numeric_limits<uint64_t>::max();
  }
  if (bits <= 0) {
    return 0;
  }

  return (1ULL << bits) - 1;
}

// sign extension
template <int len> constexpr int64_t SEXT(uint64_t x) {
  static_assert(len > 0 && len <= 64, "Bit length must be between 1 and 64.");

  if constexpr (len == 64) {
    return x;
  } else {
    uint64_t sign_bit = 1ULL << (len - 1);
    // if negative
    if ((x & sign_bit) != 0) {
      // set bits higher than `len`-1 to 1
      return x | (~BITMASK(len));
    }

    // if positive, pass
    return x;
  }
}

// extract bits at [`hi`, `lo`] (inclusive interval)
constexpr uint64_t BITS(uint64_t x, int hi, int lo) {
  assert(hi >= lo);
  return (x >> lo) & BITMASK(hi - lo + 1);
}

namespace RISCV {

static constexpr int REGNUM = 32;
using RegId = int; // -1 means none
using Regs = std::array<uint64_t, REGNUM>;

enum Reg {
  REG_ZERO = 0,
  REG_RA = 1,
  REG_SP = 2,
  REG_GP = 3,
  REG_TP = 4,
  REG_T0 = 5,
  REG_T1 = 6,
  REG_T2 = 7,
  REG_S0 = 8,
  REG_S1 = 9,
  REG_A0 = 10,
  REG_A1 = 11,
  REG_A2 = 12,
  REG_A3 = 13,
  REG_A4 = 14,
  REG_A5 = 15,
  REG_A6 = 16,
  REG_A7 = 17,
  REG_S2 = 18,
  REG_S3 = 19,
  REG_S4 = 20,
  REG_S5 = 21,
  REG_S6 = 22,
  REG_S7 = 23,
  REG_S8 = 24,
  REG_S9 = 25,
  REG_S10 = 26,
  REG_S11 = 27,
  REG_T3 = 28,
  REG_T4 = 29,
  REG_T5 = 30,
  REG_T6 = 31,
};

inline const char *REGNAME[] = {
    "zero", // x0
    "ra",   // x1
    "sp",   // x2
    "gp",   // x3
    "tp",   // x4
    "t0",   // x5
    "t1",   // x6
    "t2",   // x7
    "s0",   // x8
    "s1",   // x9
    "a0",   // x10
    "a1",   // x11
    "a2",   // x12
    "a3",   // x13
    "a4",   // x14
    "a5",   // x15
    "a6",   // x16
    "a7",   // x17
    "s2",   // x18
    "s3",   // x19
    "s4",   // x20
    "s5",   // x21
    "s6",   // x22
    "s7",   // x23
    "s8",   // x24
    "s9",   // x25
    "s10",  // x26
    "s11",  // x27
    "t3",   // x28
    "t4",   // x29
    "t5",   // x30
    "t6",   // x31
};

enum InstLargeType {
  R_TYPE,
  I_TYPE,
  S_TYPE,
  SB_TYPE,
  U_TYPE,
  UJ_TYPE,
};

enum InstType {
  UNKNOWN = -1,
  LUI = 0,
  AUIPC = 1,
  JAL = 2,
  JALR = 3,
  BEQ = 4,
  BNE = 5,
  BLT = 6,
  BGE = 7,
  BLTU = 8,
  BGEU = 9,
  LB = 10,
  LH = 11,
  LW = 12,
  LD = 13,
  LBU = 14,
  LHU = 15,
  SB = 16,
  SH = 17,
  SW = 18,
  SD = 19,
  ADDI = 20,
  SLTI = 21,
  SLTIU = 22,
  XORI = 23,
  ORI = 24,
  ANDI = 25,
  SLLI = 26,
  SRLI = 27,
  SRAI = 28,
  ADD = 29,
  SUB = 30,
  SLL = 31,
  SLT = 32,
  SLTU = 33,
  XOR = 34,
  SRL = 35,
  SRA = 36,
  OR = 37,
  AND = 38,
  ECALL = 39,
  ADDIW = 40,
  MUL = 41,
  DIV = 42,
  REM = 43,
  LWU = 44,
  SLLIW = 45,
  SRLIW = 46,
  SRAIW = 47,
  ADDW = 48,
  SUBW = 49,
  SLLW = 50,
  SRLW = 51,
  SRAW = 52,
  MULH=53,
  MULHU=54,
  MULHSU=55,
  DIVU=56,
  REMU=57,

  MULW=58,
  DIVW=59,
  DIVUW=60,
  REMW=61,
  REMUW=62
};

inline const char *INSTNAME[]{
    "lui",   "auipc", "jal",   "jalr",  "beq",   "bne",  "blt",  "bge",  "bltu",
    "bgeu",  "lb",    "lh",    "lw",    "ld",    "lbu",  "lhu",  "sb",   "sh",
    "sw",    "sd",    "addi",  "slti",  "sltiu", "xori", "ori",  "andi", "slli",
    "srli",  "srai",  "add",   "sub",   "sll",   "slt",  "sltu", "xor",  "srl",
    "sra",   "or",    "and",   "ecall", "addiw", "mul",  "div",  "rem",  "lwu",
    "slliw", "srliw", "sraiw", "addw",  "subw",  "sllw", "srlw", "sraw","mulh",
    "mulhu", "mulhsu", "divu", "remu", "mulw", "divw", "divuw", "remw", "remuw"
};

// Opcode field
static constexpr int OP_REG = 0x33;
static constexpr int OP_IMM = 0x13;
static constexpr int OP_LUI = 0x37;
static constexpr int OP_BRANCH = 0x63;
static constexpr int OP_STORE = 0x23;
static constexpr int OP_LOAD = 0x03;
static constexpr int OP_SYSTEM = 0x73;
static constexpr int OP_AUIPC = 0x17;
static constexpr int OP_JAL = 0x6F;
static constexpr int OP_JALR = 0x67;
static constexpr int OP_IMM32 = 0x1B;
static constexpr int OP_32 = 0x3B;

inline bool IsBranch(InstType instType) {
  return instType == BEQ || instType == BNE || instType == BLT ||
         instType == BGE || instType == BLTU || instType == BGEU;
}

inline bool IsJump(InstType instType) {
  return instType == JAL || instType == JALR;
}
inline bool IsPredicted(InstType instType) {
  return IsBranch(instType) || instType == JAL;
}
inline bool IsReadMem(InstType instType) {
  return instType == LB || instType == LH || instType == LW || instType == LD ||
         instType == LBU || instType == LHU || instType == LWU;
}
inline bool IsWriteMem(InstType instType) {
  return instType == RISCV::SB || instType == RISCV::SH ||
         instType == RISCV::SW || instType == RISCV::SD;
}

inline bool IsMulType(RISCV::InstType inst_type) {
  return inst_type == RISCV::MUL || inst_type == RISCV::DIV || inst_type == RISCV::REM ||
   inst_type == RISCV::MULH || inst_type == RISCV::MULHU || inst_type == RISCV::MULHSU ||
   inst_type == RISCV::DIVU || inst_type == RISCV::REMU || inst_type == RISCV::MULW ||
   inst_type == RISCV::DIVW || inst_type == RISCV::DIVUW || inst_type == RISCV::REMW ||
   inst_type == RISCV::REMUW;
}
inline bool IsMemType(RISCV::InstType inst_type) {
  return IsReadMem(inst_type) || IsWriteMem(inst_type);
}
inline bool RType(InstType instType) {
  return instType == ADD || instType == SUB || instType == SLL ||
         instType == SLT || instType == SLTU || instType == XOR ||
         instType == SRL || instType == SRA || instType == OR ||
         instType == ADDW || instType == SUBW || instType == SLLW ||instType == SRLW || instType == SRAW || 
         instType == AND ||IsMulType(instType);
}
inline bool SType(InstType instType) { return IsWriteMem(instType); }
inline bool BType(InstType instType) { return IsBranch(instType); }
inline bool UType(InstType instType) {
  return instType == LUI || instType == AUIPC;
}
inline bool JType(InstType instType) { return instType == JAL; }

inline bool IType(InstType instType) {
  return IsReadMem(instType) || instType == JALR || instType == ADDI ||
         instType == SLTI || instType == SLTIU || instType == XORI ||
         instType == ORI || instType == ANDI || instType == SLLI ||
         instType == SRLI || instType == SRAI || instType ==ADDIW ||
         instType == SLLIW || instType == SRLIW || instType == SRAIW 
         ;
}
inline bool TwoOP(InstType instType) {
  return RType(instType) || SType(instType) || BType(instType) || instType==ECALL;
}
inline bool OneOP(InstType instType) { return IType(instType); }
inline bool W2Rd(InstType instType) {
  return RType(instType) || IType(instType) || UType(instType) ||
         JType(instType)|| instType==ECALL;
}

struct PipeOp {
  // fetch
  uint64_t pc = 0;
  uint32_t pc_len = 4;
  uint32_t inst = 0;

  // decode
  InstType inst_type = UNKNOWN;
  RegId rs1 = -1, rs2 = -1;
  int64_t op1 = 0, op2 = 0;
  RegId dest_reg = -1;
  int64_t offset = 0;
  // internal decode result
  std::string inst_str;

  // execute
  int64_t out = 0;
  bool write_mem = false;
  bool read_mem = false;
  bool read_sign_ext = false;
  uint32_t mem_len = 0;
  bool branch = false;
  uint32_t jump_pc = 0;

  int remaining_cycles = 1; // 剩余执行周期
 //branch_predictor-adding 
  bool branch_taken = false; //默认情况: always not taken
  uint32_t branch_target = 0;
  bool is_illegal=false;
  bool has_exception = false;
  bool ex_illegal = false;

};

// simulator-irrelavant decoder and executor
void DecodeInst(PipeOp *op, const Regs &regs);
void ExecuteInst(PipeOp *op, bool *exit_ctrl, MemoryManager *mem);
} // namespace RISCV

#endif
